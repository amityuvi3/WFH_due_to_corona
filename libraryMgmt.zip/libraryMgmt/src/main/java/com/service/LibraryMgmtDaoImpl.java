package com.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.BookBean;
import com.model.RegistrationBean;
import com.tr.repository.BookBeanRepository;
import com.tr.repository.RegistrationBeanRepository;
import com.tr.repository.UserNormBeanRepository;
@Service
public class LibraryMgmtDaoImpl implements LibraryMgmtDao {

	@Autowired
	RegistrationBeanRepository 	registrationBeanRepository;
	
	@Autowired
	 BookBeanRepository bookBeanRepository;
	
	@Autowired
	 UserNormBeanRepository userNormBeanRepository;
	
	@Override
	public RegistrationBean validateLogin(RegistrationBean registrartionBean) {
		
		return registrationBeanRepository.loginValidation(registrartionBean.getUserId(), registrartionBean.getPassword());
	}
	
	@Override
	public RegistrationBean validateUserId(RegistrationBean registrartionBean) {
		
		return registrationBeanRepository.userIdValidation(registrartionBean.getUserId());
	}
	

	@Override
	public double register(RegistrationBean registrationBean) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public BookBean bookValidation(int bookId) {
		
		return bookBeanRepository.bookValidation(bookId);
	}

	public List<BookBean> getSortedBooksBySubject_NameInAsc() {
		
		return bookBeanRepository.sortBySubject_NameInAsc();
	}

	public List<BookBean> getSortedBooksByBook_NameInAsc() {
		return bookBeanRepository.sortByBook_NameInAsc();
	}

	public List<BookBean> getSortedBooksByAuthor_NameInAsc() {
		return bookBeanRepository.sortByAuthor_NameInAsc();
	}

	public List<BookBean> getSortedBooksByBook_IdInAsc() {
		return bookBeanRepository.sortByBook_IdInAsc();
	}

//	public List<BookBean> getSortedBooksByBook_NumberInAsc() {
//		return bookBeanRepository.sortByBook_NumberInAsc();
//	}
public List<BookBean> getSortedBooksBySubject_NameInDesc() {
		
		return bookBeanRepository.sortBySubject_NameInDesc();
	}

	public List<BookBean> getSortedBooksByBook_NameInDesc() {
		return bookBeanRepository.sortByBook_NameInDesc();
	}

	public List<BookBean> getSortedBooksByAuthor_NameInDesc() {
		return bookBeanRepository.sortByAuthor_NameInDesc();
	}

	public List<BookBean> getSortedBooksByBook_IdInDesc() {
		return bookBeanRepository.sortByBook_IdInDesc();
	}

	public void updateUserNorm(String dosUserNorm,String dontsUserNorm,  int userNormId) {
		userNormBeanRepository.updateUserNormRepository(dosUserNorm,dontsUserNorm,userNormId);
		
	}

	public void updateLibrarian(String firstName, String lastName, String contactNumber, String userId) {
		registrationBeanRepository.updateLibrarianDetail(firstName,lastName,contactNumber,userId);
		
	}

	public RegistrationBean findUser(String userId) {
		
		return registrationBeanRepository.find(userId);
	}


	public void updateIssueBook(String issueTo, Date issueDate, Date dueDate, Date returnDate, int bookId) {
		bookBeanRepository.updateIssueToBook(issueTo,issueDate,dueDate,returnDate,bookId);
		
	}

//	public List<BookBean> getSortedBooksByBook_NumberInDesc() {
//		return bookBeanRepository.sortByBook_NumberInDesc();
//	}

}
