package com.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.BookBean;
import com.model.RegistrationBean;

@Service
public interface LibraryMgmtDao {
	
	public double register(RegistrationBean registrationBean);
	public RegistrationBean validateLogin(RegistrationBean registrartionBean);
	public BookBean bookValidation(int bookId);
	public RegistrationBean validateUserId(RegistrationBean registrartionBean);
	
	public List<BookBean> getSortedBooksBySubject_NameInAsc();
	public List<BookBean> getSortedBooksByBook_NameInAsc();
	public List<BookBean> getSortedBooksByAuthor_NameInAsc() ;
	public List<BookBean> getSortedBooksByBook_IdInAsc();
	//public List<BookBean> getSortedBooksByBook_NumberInAsc();
	
	public List<BookBean> getSortedBooksBySubject_NameInDesc();
	public List<BookBean> getSortedBooksByBook_NameInDesc();
	public List<BookBean> getSortedBooksByAuthor_NameInDesc() ;
	public List<BookBean> getSortedBooksByBook_IdInDesc();
	//public List<BookBean> getSortedBooksByBook_NumberInDesc();
	
	public void updateUserNorm(String dosUserNorm,String dontsUserNorm,  int userNormId);
	
	public void updateLibrarian(String firstName, String lastName, String contactNumber, String userId);
}
