package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.BookBean;
import com.model.RegistrationBean;
import com.service.LibraryMgmtDaoImpl;
import com.tr.repository.RegistrationBeanRepository;

@Controller
public class RegistrationController {

	HttpSession session;

	@Autowired
	private LibraryMgmtDaoImpl libraryMgmtDaoImpl;
	@Autowired
	RegistrationBeanRepository registerBeanRepository;
	
	
	@RequestMapping(value = "/admin_home", method = RequestMethod.GET)
	public String admin_home() {
		
		return "admin_home";
	}
	@RequestMapping(value = "/super_admin_home", method = RequestMethod.GET)
	public String super_admin_home() {
		
		return "super_admin_home";
	}
	
	@RequestMapping(value = "/librarian_home", method = RequestMethod.GET)
	public String librarian_home() {
		
		return "librarian_home";
	}
	
	@RequestMapping(value = "/user_home", method = RequestMethod.GET)
	public String user_home() {
		
		return "user_home";
	}
	
	
	@RequestMapping(value = "/loginpage", method = RequestMethod.GET)
	public String loginPage(@ModelAttribute("login") RegistrationBean registrationBean) {
		registrationBean = new RegistrationBean();

		return "index";
	}

	@RequestMapping(value = "/registerPage", method = RequestMethod.GET)
	public String registerPage(@ModelAttribute("register") RegistrationBean registrationBean) {
		registrationBean = new RegistrationBean();

		return "registrationpage";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String register(@Valid @ModelAttribute("register") RegistrationBean registrationBean, BindingResult result, Model model) {
	// validator.validate(registrationBean, result);
	if (result.hasErrors()) {
	return "registrationpage";
	}
	if( libraryMgmtDaoImpl.validateUserId(registrationBean)==null) {

	registerBeanRepository.save(registrationBean);
	return "registerSuccess";
	}
	model.addAttribute("invalidId", "User id is already registered");
	return "registrationpage";
	}
	
	@RequestMapping("/logout")
    public String logout(){
           return "logout";
    }
	@RequestMapping("/contact")
    public String contact(){
           return "contact";
    }
	@RequestMapping("/about")
    public String about(){
           return "about";
    }
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(@Valid @ModelAttribute("login") RegistrationBean registrationBean, BindingResult result,
                  HttpServletRequest request, ModelMap model) {
           // validator.validate(registrationBean, result);
           
           
           if(registrationBean.getUserId().equals("")){
                  return "index";
           }
           if(registrationBean.getPassword().equals("")){
                  return "index";
           }
           
           RegistrationBean registrationBean1 = null;    
           
           
           registrationBean1 = libraryMgmtDaoImpl.validateLogin(registrationBean);
           
           
           if (registrationBean1 != null) {
        	   
        	   		if(registrationBean1.getStatus().equals("not approved")){
        	   			model.addAttribute("errorStatus","User is not approved");
        	   			return "index";
        	   		}
        	   
                  String category = null;
                  category = registrationBean1.getCategory();
                  System.out.println(category);
                  
                  if (category.equals("SuperAdmin")) {
                      if (registrationBean1.getFirstName() != null) {
                             session = request.getSession();
                             session.setAttribute("username", registrationBean1.getFirstName());
                         	session.setAttribute("lastname", registrationBean1.getLastName());
                         	session.setAttribute("category", registrationBean1.getCategory());
                         	session.setAttribute("userId", registrationBean1.getUserId());
                         	session.setAttribute("dob", registrationBean1.getdOB());
                         	session.setAttribute("contactno", registrationBean1.getContactNumber());
                             return "super_admin_home";
                      } else if (result.hasErrors()) {
                             return "index";
                      }

                }
                  if (category.equals("Admin")) {
                        if (registrationBean1.getFirstName() != null) {
                               session = request.getSession();
                               session.setAttribute("username", registrationBean1.getFirstName());
                           	session.setAttribute("lastname", registrationBean1.getLastName());
                           	session.setAttribute("category", registrationBean1.getCategory());
                           	session.setAttribute("userId", registrationBean1.getUserId());
                           	session.setAttribute("dob", registrationBean1.getdOB());
                           	session.setAttribute("contactno", registrationBean1.getContactNumber());
                               return "admin_home";
                        } else if (result.hasErrors()) {
                               return "index";
                        }

                  }
                  if (category.equals("User")) {
                        if (registrationBean1.getFirstName() != null) {
                               session = request.getSession();
                               session.setAttribute("username", registrationBean1.getFirstName());
                           	session.setAttribute("lastname", registrationBean1.getLastName());
                           	session.setAttribute("category", registrationBean1.getCategory());
                           	session.setAttribute("userId", registrationBean1.getUserId());
                           	session.setAttribute("dob", registrationBean1.getdOB());
                           	session.setAttribute("contactno", registrationBean1.getContactNumber());
                               return "user_home";
                        } else if (result.hasErrors()) {
                               return "index";
                        }

                  }
                  if (category.equals("Librarian")) {
                        if (registrationBean1.getFirstName() != null) {
                               session = request.getSession();
                               session.setAttribute("username", registrationBean1.getFirstName());
                           	session.setAttribute("lastname", registrationBean1.getLastName());
                           	session.setAttribute("category", registrationBean1.getCategory());
                           	session.setAttribute("userId", registrationBean1.getUserId());
                           	session.setAttribute("dob", registrationBean1.getdOB());
                           	session.setAttribute("contactno", registrationBean1.getContactNumber());
                               return "librarian_home";
                        } else if (result.hasErrors()) {
                               return "index";
                        }

                  }
                  
     
           }
           
           else if(registrationBean1==null){       
                  
                  registrationBean1 = libraryMgmtDaoImpl.validateUserId(registrationBean);
                  
                  if(registrationBean1==null){
                  model.addAttribute("errorUserId","Invalid user id");
                  }else
                        {
                	  
                	  		model.addAttribute("errorPassword","Invalid password");
                        
                        }
                  return "index";
           }
           
           
           
           return "index";
    }



	@RequestMapping("/register")
	public String addProduct(@Valid @ModelAttribute("register") RegistrationBean registrationBean,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {

			return "registrationFail";
		}
		registerBeanRepository.save(registrationBean);
		return "redirect:/loginpage";
	}

	@ModelAttribute("categoryList")
	public List<String> populateExpense() {
		List<String> categoryListType = new ArrayList<String>();
		categoryListType.add("Admin");
		categoryListType.add("Librarian");
		categoryListType.add("User");
		return categoryListType;
	}
	
	@RequestMapping("/viewLibrarianDetails1")
    public String viewLibrarianDetails1(Model m) {
           
           List<RegistrationBean> registrationBeans = registerBeanRepository.getLibrarianDetails("Librarian");
           m.addAttribute("viewLibrarianlist",registrationBeans);
           return "librarianDetails1";
    }
    
    @RequestMapping("/deleteLibrarian1")
    public String delete1(@RequestParam String userId) {
           
           
           registerBeanRepository.deleteByUserId(userId);
           System.out.println(userId +"deleted");
    
           return "redirect:/viewLibrarianDetails1";
    }
    
    @RequestMapping("/pendingRequests")
    public String viewPendingRequests(Model m) {
           
           List<RegistrationBean> registrationBeans = registerBeanRepository.getPendingRequests("not approved");
           m.addAttribute("viewnotApprovedlist",registrationBeans);
           return "requests";
    }
    
    @RequestMapping("/approveUser")
    public String update(@RequestParam String userId) {
           
           
           registerBeanRepository.updateStatus("approved",userId);
           System.out.println(userId +" Approved");
    
           return "redirect:/pendingRequests";
    }
	//showupdateLibrarianDetail?userId=amit@gmail.com
    @RequestMapping(value = "/showupdateLibrarianDetail", method = RequestMethod.GET)
	public String showupdateLibrarian(@ModelAttribute("updateLibrarianDetail")RegistrationBean registrationBean,@RequestParam String userId,Model model,HttpServletRequest request) {
    	 session = request.getSession();
    	 registrationBean=new RegistrationBean();
    	String uId= (String) session.getAttribute("userId");
     
		registrationBean = libraryMgmtDaoImpl.findUser(uId);

		model.addAttribute(registrationBean);

		return "updateLibrarianDetail";
	}

	@RequestMapping("/updateLibrarianDetail")
	public String updateLibrarianDetail(@Valid @ModelAttribute("updateLibrarianDetail")RegistrationBean registrationBean, BindingResult result, @RequestParam String userId , Model model,HttpServletRequest request) {
		if (result.hasErrors()) {
			return "updateLibrarianDetail";
		}
//		if(registrationBean.getFirstName().equals(null)) {
//			model.addAttribute("firstNameRequired", "First Name Required");
//		}
		libraryMgmtDaoImpl.updateLibrarian(registrationBean.getFirstName(),registrationBean.getLastName(),registrationBean.getContactNumber(),userId);
		  session = request.getSession();
          session.setAttribute("username", registrationBean.getFirstName());
      	session.setAttribute("lastname", registrationBean.getLastName());
      	session.setAttribute("category", registrationBean.getCategory());
      	session.setAttribute("userId", registrationBean.getUserId());
      	session.setAttribute("dob", registrationBean.getdOB());
      	session.setAttribute("contactno", registrationBean.getContactNumber());
		return "redirect:/librarian_home";
	}


	//Admin
	@RequestMapping("/viewLibrarianDetails2")
    public String viewLibrarianDetails2(Model m) {
           
           List<RegistrationBean> registrationBeans = registerBeanRepository.getLibrarianDetails("Librarian");
           m.addAttribute("viewLibrarianlist",registrationBeans);
           return "librarianDetails2";
    }
    
    @RequestMapping("/deleteLibrarian2")
    public String delete2(@RequestParam String userId) {
           
           
           registerBeanRepository.deleteByUserId(userId);
           System.out.println(userId +"deleted");
    
           return "redirect:/viewLibrarianDetails2";
    }
}
