package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.BookBean;
import com.service.LibraryMgmtDaoImpl;
import com.tr.repository.BookBeanRepository;

@Controller
public class BookController {

	HttpSession session;

	@Autowired
	private LibraryMgmtDaoImpl libraryMgmtDaoImpl;

	@Autowired
	private BookBeanRepository bookBeanRepository;

	//Super_Admin
	@RequestMapping(value = "/showaddpage1", method = RequestMethod.GET)
	public String loginPage1(@ModelAttribute("addBook") BookBean bookBean) {
		bookBean = new BookBean();

		return "addBook1";
	}

	@RequestMapping(value = "/addBook1", method = RequestMethod.POST)
	public String register1(@Valid @ModelAttribute("addBook") BookBean bookBean, BindingResult result, Model model) {
		// validator.validate(registrationBean, result);
		if (result.hasErrors()) {
			return "addBook1";
		}
		if (bookBeanRepository.validateBookNumber(bookBean.getBookNumber()) != null) {
			model.addAttribute("invalidBookNumber", "Book Number is already registered");
			return "addBook1";
		}
		bookBeanRepository.save(bookBean);
		return "redirect:/viewBook1";

	}

	@RequestMapping("/viewBook1")
	public String viewallProduct1(Model m) {

		List<BookBean> productlist = bookBeanRepository.findAll();
		m.addAttribute("viewBooklist", productlist);
		return "viewBook1";
	}

	@RequestMapping("/deleteBook1")
	public String delete1(@RequestParam int bookId) {
		bookBeanRepository.deleteById(bookId);
		// System.out.println(bookId + "deleted");

		return "redirect:/viewBook1";
	}

	@RequestMapping(value = "/showupdatepage1", method = RequestMethod.GET)
	public String showupdatepage1(@RequestParam int bookId, Model model) {
		BookBean bookBean = bookBeanRepository.getOne(bookId);

		// System.out.println(bookBean);
		// model.addAttribute("bookId", bookId);
		model.addAttribute(bookBean);

		return "updateBook1";
	}

	@RequestMapping("/updateBook1")
	public String updateProduct1(@ModelAttribute("bookBean") @RequestParam int bookId, BookBean bookBean, Model model) {

		bookBeanRepository.updateBook(bookBean.getSubject(), bookBean.getBookName(), bookBean.getAuthorName(), bookId);

		return "redirect:/viewBook1";
	}

	@RequestMapping("/searchBook1")
	public String searchbyCategory1(@RequestParam String category, @RequestParam String bookCategory,
			HttpServletRequest request, Model model) {

		List<BookBean> bookList = null;
		if (bookCategory.equalsIgnoreCase("author_name")) {
			bookList = bookBeanRepository.getBooksByCategoryAuthor_Name(category);
		} else if (bookCategory.equalsIgnoreCase("book_name")) {
			bookList = bookBeanRepository.getBooksByCategoryBook_Name(category);
		} else if (bookCategory.equalsIgnoreCase("subject")) {
			bookList = bookBeanRepository.getBooksByCategorySubject_Name(category);
		}
		if (bookList == null) {
			model.addAttribute("BookNotFound", "Book is not available");
			return "searchBook1";
		}
		session = request.getSession();
		session.setAttribute("bookBeanList", bookList);
		// session.removeAttribute("bookBeanList");
		return "searchBook1";
	}

	@RequestMapping("/searchBooks1")
	public String searchByCategory1() {
		return "searchBook1";
	}

	@RequestMapping("/sortBook1")
	public String sortBook1(@RequestParam String sortCategory, @RequestParam String sortOrder,
			HttpServletRequest request, Model model) {

		List<BookBean> bookList = null;
		if (sortOrder.equals("asc")) {
			if (sortCategory.equalsIgnoreCase("author_name")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInAsc();
			} else if (sortCategory.equalsIgnoreCase("book_name")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInAsc();
			} else if (sortCategory.equalsIgnoreCase("subject")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInAsc();
			} else if (sortCategory.equalsIgnoreCase("book_id")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInAsc();
			}

		} else if (sortOrder.equals("desc")) {
			if (sortCategory.equalsIgnoreCase("author_name")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInDesc();
			} else if (sortCategory.equalsIgnoreCase("book_name")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInDesc();
			} else if (sortCategory.equalsIgnoreCase("subject")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInDesc();
			} else if (sortCategory.equalsIgnoreCase("book_id")) {
				bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInDesc();
			}
		
		}
		if (bookList == null) {
			model.addAttribute("BookNotFound", "Book is not available");
			return "sortBook1";
		}

		session = request.getSession();
		session.setAttribute("sotedBookList", bookList);
		// session.removeAttribute("bookBeanList");
		return "sortBook1";
	}

	@RequestMapping("/sortBooks1")
	public String sortBook1() {
		return "sortBook1";
	}


	@RequestMapping(value = "/showIssueBookPage", method = RequestMethod.GET)
	public String showIssue(Model model) {
	
        List<BookBean> productlist = bookBeanRepository.findAll();
		model.addAttribute("viewBooklist", productlist);
	//	model.addAttribute(bookBean);

		return "viewToIssueBook";
	}
	@RequestMapping(value = "/showIssueBook", method = RequestMethod.GET)
	public String showIssue1(@RequestParam int bookId, Model model) {
		System.out.println(bookId);
		BookBean bookBean = bookBeanRepository.getOne(bookId);
        System.out.println(bookId);
    
		model.addAttribute(bookBean);

		return "issueBook";
	}

	@RequestMapping("/issueBook")
	public String updateIssuedBook(@ModelAttribute("bookBean")  BookBean bookBean,@RequestParam int bookId, Model model) {

		libraryMgmtDaoImpl.updateIssueBook(bookBean.getIssueTo(),bookBean.getIssueDate(),bookBean.getDueDate(),bookBean.getReturnDate(),bookId);
      model.addAttribute("bookIssued",bookId+" issued");
      List<BookBean> productlist = bookBeanRepository.findAll();
		model.addAttribute("viewBooklist", productlist);
	
		return "viewToIssueBook";
	}
	
	@RequestMapping("/viewToIssueBook")
	public String viewToIssueBook(Model model) {
		 List<BookBean> productlist = bookBeanRepository.findAll();
			model.addAttribute("viewBooklist", productlist);
		
		return "redirect:/viewToIssueBook";
	}

	
	//Admin
		@RequestMapping(value = "/showaddpage2", method = RequestMethod.GET)
		public String loginPage2(@ModelAttribute("addBook") BookBean bookBean) {
			bookBean = new BookBean();

			return "addBook2";
		}

		@RequestMapping(value = "/addBook2", method = RequestMethod.POST)
		public String register2(@Valid @ModelAttribute("addBook") BookBean bookBean, BindingResult result, Model model) {
			// validator.validate(registrationBean, result);
			if (result.hasErrors()) {
				return "addBook2";
			}
			if (bookBeanRepository.validateBookNumber(bookBean.getBookNumber()) != null) {
				model.addAttribute("invalidBookNumber", "Book Number is already registered");
				return "addBook2";
			}
			bookBeanRepository.save(bookBean);
			return "redirect:/viewBook2";

		}

		@RequestMapping("/viewBook2")
		public String viewallProduct2(Model m) {

			List<BookBean> productlist = bookBeanRepository.findAll();
			m.addAttribute("viewBooklist", productlist);
			return "viewBook2";
		}

		@RequestMapping("/deleteBook2")
		public String delete2(@RequestParam int bookId) {
			bookBeanRepository.deleteById(bookId);
			// System.out.println(bookId + "deleted");

			return "redirect:/viewBook2";
		}

		@RequestMapping(value = "/showupdatepage2", method = RequestMethod.GET)
		public String showupdatepage2(@RequestParam int bookId, Model model) {
			BookBean bookBean = bookBeanRepository.getOne(bookId);

			model.addAttribute(bookBean);

			return "updateBook2";
		}

		@RequestMapping("/updateBook2")
		public String updateProduc2(@ModelAttribute("bookBean") @RequestParam int bookId, BookBean bookBean, Model model) {

			bookBeanRepository.updateBook(bookBean.getSubject(), bookBean.getBookName(), bookBean.getAuthorName(), bookId);

			return "redirect:/viewBook2";
		}

		@RequestMapping("/searchBook2")
		public String searchbyCategory2(@RequestParam String category, @RequestParam String bookCategory,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (bookCategory.equalsIgnoreCase("author_name")) {
				bookList = bookBeanRepository.getBooksByCategoryAuthor_Name(category);
			} else if (bookCategory.equalsIgnoreCase("book_name")) {
				bookList = bookBeanRepository.getBooksByCategoryBook_Name(category);
			} else if (bookCategory.equalsIgnoreCase("subject")) {
				bookList = bookBeanRepository.getBooksByCategorySubject_Name(category);
			}
			if (bookList == null) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "searchBook2";
			}
			session = request.getSession();
			session.setAttribute("bookBeanList", bookList);
			// session.removeAttribute("bookBeanList");
			return "searchBook2";
		}

		@RequestMapping("/searchBooks2")
		public String searchByCategory2() {
			return "searchBook2";
		}

		@RequestMapping("/sortBook2")
		public String sortBook2(@RequestParam String sortCategory, @RequestParam String sortOrder,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (sortOrder.equals("asc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInAsc();
				}

			} else if (sortOrder.equals("desc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInDesc();
				}
			
			}
			if (bookList == null) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "sortBook2";
			}

			session = request.getSession();
			session.setAttribute("sotedBookList", bookList);
			// session.removeAttribute("bookBeanList");
			return "sortBook2";
		}

		@RequestMapping("/sortBooks2")
		public String sortBook2() {
			return "sortBook2";
		}

		//Librarian
		@RequestMapping("/viewBook3")
		public String viewallProduct3(Model m) {

			List<BookBean> productlist = bookBeanRepository.findAll();
			m.addAttribute("viewBooklist", productlist);
			return "viewBook3";
		}
		@RequestMapping("/searchBook3")
		public String searchbyCategory3(@RequestParam String category, @RequestParam String bookCategory,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (bookCategory.equalsIgnoreCase("author_name")) {
				bookList = bookBeanRepository.getBooksByCategoryAuthor_Name(category);
			} else if (bookCategory.equalsIgnoreCase("book_name")) {
				bookList = bookBeanRepository.getBooksByCategoryBook_Name(category);
			} else if (bookCategory.equalsIgnoreCase("subject")) {
				bookList = bookBeanRepository.getBooksByCategorySubject_Name(category);
			}
			if (bookList == null) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "searchBook3";
			}
			session = request.getSession();
			session.setAttribute("bookBeanList", bookList);
			// session.removeAttribute("bookBeanList");
			return "searchBook3";
		}

		@RequestMapping("/searchBooks3")
		public String searchByCategory3() {
			return "searchBook3";
		}

		@RequestMapping("/sortBook3")
		public String sortBook3(@RequestParam String sortCategory, @RequestParam String sortOrder,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (sortOrder.equals("asc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInAsc();
				}

			} else if (sortOrder.equals("desc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInDesc();
				}
			
			}
			if (bookList == null) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "sortBook3";
			}

			session = request.getSession();
			session.setAttribute("sotedBookList", bookList);
			// session.removeAttribute("bookBeanList");
			return "sortBook3";
		}

		@RequestMapping("/sortBooks3")
		public String sortBook3() {
			return "sortBook3";
		}
		
		//User
		@RequestMapping("/viewBook4")
		public String viewallProduct4(Model m) {

			List<BookBean> productlist = bookBeanRepository.findAll();
			m.addAttribute("viewBooklist", productlist);
			return "viewBook4";
		}
		@RequestMapping("/searchBook4")
		public String searchbyCategory4(@RequestParam String category, @RequestParam String bookCategory,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (bookCategory.equalsIgnoreCase("author_name")) {
				bookList = bookBeanRepository.getBooksByCategoryAuthor_Name(category);
			} else if (bookCategory.equalsIgnoreCase("book_name")) {
				bookList = bookBeanRepository.getBooksByCategoryBook_Name(category);
			} else if (bookCategory.equalsIgnoreCase("subject")) {
				bookList = bookBeanRepository.getBooksByCategorySubject_Name(category);
			}
			if (bookList.equals("null")) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "searchBook4";
			}
			session = request.getSession();
			session.setAttribute("bookBeanList", bookList);
			// session.removeAttribute("bookBeanList");
			return "searchBook4";
		}

		@RequestMapping("/searchBooks4")
		public String searchByCategory4() {
			return "searchBook4";
		}

		@RequestMapping("/sortBook4")
		public String sortBook4(@RequestParam String sortCategory, @RequestParam String sortOrder,
				HttpServletRequest request, Model model) {

			List<BookBean> bookList = null;
			if (sortOrder.equals("asc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInAsc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInAsc();
				}

			} else if (sortOrder.equals("desc")) {
				if (sortCategory.equalsIgnoreCase("author_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByAuthor_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_name")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("subject")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksBySubject_NameInDesc();
				} else if (sortCategory.equalsIgnoreCase("book_id")) {
					bookList = libraryMgmtDaoImpl.getSortedBooksByBook_IdInDesc();
				}
			
			}
			if (bookList == null) {
				model.addAttribute("BookNotFound", "Book is not available");
				return "sortBook4";
			}

			session = request.getSession();
			session.setAttribute("sotedBookList", bookList);
			// session.removeAttribute("bookBeanList");
			return "sortBook4";
		}

		@RequestMapping("/sortBooks4")
		public String sortBook4() {
			return "sortBook4";
		}
}
