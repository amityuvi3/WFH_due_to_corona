package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.BookBean;
import com.model.UserNormBean;
import com.service.LibraryMgmtDaoImpl;
import com.tr.repository.UserNormBeanRepository;

@Controller
public class UserNormController {

	@Autowired
	UserNormBeanRepository userNormBeanRepository;

	@Autowired
	private LibraryMgmtDaoImpl libraryMgmtDaoImpl;

	
	//Super_Admin
	@RequestMapping("/addUserNorms1")
	public String addUserNorm1(@ModelAttribute("addUserNorm") UserNormBean userNormBean) {
		userNormBean=new UserNormBean();
		return "addUserNorm1";
	}
	@RequestMapping("/viewUserNorm1")
	public String viewAllUserNorm1(Model m) {

		List<UserNormBean> userNormlist = userNormBeanRepository.findAll();
		m.addAttribute("viewUserNormlist", userNormlist);
		return "viewUserNorm1";
	}

	@RequestMapping(value = "/addUserNorm1", method = RequestMethod.POST)
	public String addUserNorm1(@Valid @ModelAttribute("addUserNorm") UserNormBean userNormBean, BindingResult result) {
		// validator.validate(registrationBean, result);

		if (result.hasErrors()) {
			return "addUserNorm1";
		}
		userNormBeanRepository.save(userNormBean);
		return "redirect:/viewUserNorm1";

	}
	
	@RequestMapping(value = "/showUpdateUserNorm1", method = RequestMethod.GET)
	public String showupdatepage1(@ModelAttribute("updateUserNorm") UserNormBean userNormBean ,@RequestParam int userNormId, Model model) {
		 userNormBean = userNormBeanRepository.getOne(userNormId);
     System.out.println(userNormBean);
		model.addAttribute(userNormBean);

		return "updateUserNorm1";
	}
	
	@RequestMapping("/updateUserNorm1")
	public String updateProduct1(@ModelAttribute("updateUserNorm")UserNormBean userNormBean, @RequestParam int userNormId, Model model) {

		libraryMgmtDaoImpl.updateUserNorm(userNormBean.getDosUserNorm(),userNormBean.getDontsUserNorm(), userNormId);

		return "redirect:/viewUserNorm1";
	}
	
	
	@RequestMapping("/deleteUserNorm1")
	public String delete1(@RequestParam int userNormId) {
		userNormBeanRepository.deleteById(userNormId);
		// System.out.println(bookId + "deleted");

		return "redirect:/viewUserNorm1";
	}
         
	//Admin
	@RequestMapping("/addUserNorms2")
	public String addUserNorm2(@ModelAttribute("addUserNorm") UserNormBean userNormBean) {
		userNormBean=new UserNormBean();
		return "addUserNorm2";
	}
	@RequestMapping("/viewUserNorm2")
	public String viewAllUserNorm2(Model m) {

		List<UserNormBean> userNormlist = userNormBeanRepository.findAll();
		m.addAttribute("viewUserNormlist", userNormlist);
		return "viewUserNorm2";
	}

	@RequestMapping(value = "/addUserNorm2", method = RequestMethod.POST)
	public String addUserNorm2(@Valid @ModelAttribute("addUserNorm") UserNormBean userNormBean, BindingResult result) {
		// validator.validate(registrationBean, result);

		if (result.hasErrors()) {
			return "addUserNorm2";
		}
		userNormBeanRepository.save(userNormBean);
		return "redirect:/viewUserNorm2";

	}
	
	@RequestMapping(value = "/showUpdateUserNorm2", method = RequestMethod.GET)
	public String showupdatepage2(@ModelAttribute("updateUserNorm") UserNormBean userNormBean ,@RequestParam int userNormId, Model model) {
		 userNormBean = userNormBeanRepository.getOne(userNormId);
    // System.out.println(userNormBean);
		model.addAttribute(userNormBean);

		return "updateUserNorm2";
	}
	
	@RequestMapping("/updateUserNorm2")
	public String updateProduct2(@ModelAttribute("updateUserNorm")UserNormBean userNormBean, @RequestParam int userNormId, Model model) {

		libraryMgmtDaoImpl.updateUserNorm(userNormBean.getDosUserNorm(),userNormBean.getDontsUserNorm(), userNormId);

		return "redirect:/viewUserNorm1";
	}
	
	
	@RequestMapping("/deleteUserNorm2")
	public String delete2(@RequestParam int userNormId) {
		userNormBeanRepository.deleteById(userNormId);
		// System.out.println(bookId + "deleted");

		return "redirect:/viewUserNorm2";
	}

	//Librarian
	@RequestMapping("/addUserNorms3")
	public String addUserNorm3(@ModelAttribute("addUserNorm") UserNormBean userNormBean) {
		userNormBean=new UserNormBean();
		return "addUserNorm3";
	}
	@RequestMapping("/viewUserNorm3")
	public String viewAllUserNorm3(Model m) {

		List<UserNormBean> userNormlist = userNormBeanRepository.findAll();
		m.addAttribute("viewUserNormlist", userNormlist);
		return "viewUserNorm3";
	}

	@RequestMapping(value = "/addUserNorm3", method = RequestMethod.POST)
	public String addUserNorm3(@Valid @ModelAttribute("addUserNorm") UserNormBean userNormBean, BindingResult result) {
		// validator.validate(registrationBean, result);

		if (result.hasErrors()) {
			return "addUserNorm3";
		}
		userNormBeanRepository.save(userNormBean);
		return "redirect:/viewUserNorm3";

	}
	
	@RequestMapping(value = "/showUpdateUserNorm3", method = RequestMethod.GET)
	public String showupdatepage3(@ModelAttribute("updateUserNorm") UserNormBean userNormBean ,@RequestParam int userNormId, Model model) {
		 userNormBean = userNormBeanRepository.getOne(userNormId);
     System.out.println(userNormBean);
		model.addAttribute(userNormBean);

		return "updateUserNorm3";
	}
	
	@RequestMapping("/updateUserNorm3")
	public String updateProduct3(@ModelAttribute("updateUserNorm")UserNormBean userNormBean, @RequestParam int userNormId, Model model) {

		libraryMgmtDaoImpl.updateUserNorm(userNormBean.getDosUserNorm(),userNormBean.getDontsUserNorm(), userNormId);

		return "redirect:/viewUserNorm3";
	}
	
	
	@RequestMapping("/deleteUserNorm3")
	public String delete3(@RequestParam int userNormId) {
		userNormBeanRepository.deleteById(userNormId);
		// System.out.println(bookId + "deleted");

		return "redirect:/viewUserNorm3";
	}
	
	@RequestMapping("/viewUserNorm4")
	public String viewAllUserNorm4(Model m) {

		List<UserNormBean> userNormlist = userNormBeanRepository.findAll();
		m.addAttribute("viewUserNormlist", userNormlist);
		return "viewUserNorm4";
	}
	
	
	

}
