package com.tr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.UserNormBean;

@Repository
@org.springframework.transaction.annotation.Transactional
public interface UserNormBeanRepository extends JpaRepository<UserNormBean, Integer> {

	@Modifying
	@Query("update UserNormBean unb set unb.dosUserNorm=?1,unb.dontsUserNorm =?2 where unb.userNormId=?3")
	void updateUserNormRepository(String dosUserNorm, String dontsUserNorm2, int userNormId);

		
}
