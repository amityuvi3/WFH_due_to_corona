package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

@Component
@Entity
public class UserNormBean {
	
	@Id
	@GeneratedValue
	private int userNormId;
	@NotEmpty(message = "It is required")
	private String dosUserNorm;
	@NotEmpty(message = "It is required")
	private String dontsUserNorm;
	public int getUserNormId() {
		return userNormId;
	}
	public void setUserNormId(int userNormId) {
		this.userNormId = userNormId;
	}
	public String getDosUserNorm() {
		return dosUserNorm;
	}
	public void setDosUserNorm(String dosUserNorm) {
		this.dosUserNorm = dosUserNorm;
	}
	public String getDontsUserNorm() {
		return dontsUserNorm;
	}
	public void setDontsUserNorm(String dontsUserNorm) {
		this.dontsUserNorm = dontsUserNorm;
	}
	@Override
	public String toString() {
		return "UserNormBean [userNormId=" + userNormId + ", dosUserNorm=" + dosUserNorm + ", dontsUserNorm="
				+ dontsUserNorm + "]";
	}
	
	
	
	
	
}
